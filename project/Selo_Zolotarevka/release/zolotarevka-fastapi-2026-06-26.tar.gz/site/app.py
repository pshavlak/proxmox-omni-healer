#!/usr/bin/env python3
"""
Золотаревка — FastAPI приложение.
Запуск: uvicorn app:app --reload
"""
import os
import json
import sqlite3
import hashlib
from datetime import datetime, timedelta
from pathlib import Path
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, UploadFile, File, Form, HTTPException, Body
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from jinja2 import Environment, FileSystemLoader, select_autoescape

import config as cfg
from database import get_db, init_db
from models import PageCreate, PageUpdate, BlockCreate, RoleCreate, SuggestionCreate, ReorderRequest


# ====== Jinja2 шаблоны ======
jinja_env = Environment(
    loader=FileSystemLoader(cfg.TEMPLATE_DIR),
    autoescape=select_autoescape(["html", "xml"]),
)

# Добавляем фильтр from_json для парсинга JSON в шаблонах
jinja_env.filters["from_json"] = lambda v: json.loads(v) if isinstance(v, str) else (v or [])
jinja_env.filters["to_json"] = lambda v: json.dumps(v, ensure_ascii=False)
jinja_env.globals["now"] = datetime.now


def render(template_name: str, **kwargs) -> str:
    """Рендер Jinja2 шаблона с общими переменными."""
    tpl = jinja_env.get_template(template_name)
    return tpl.render(**kwargs)


# ====== Lifespan ======
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Инициализация при запуске."""
    from database import init_db, seed_db
    init_db()
    seed_db()
    # Создаём директорию для загрузок
    os.makedirs(cfg.UPLOAD_DIR, exist_ok=True)
    yield


# ====== FastAPI ======
app = FastAPI(title="Золотаревка", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Статика
app.mount("/static", StaticFiles(directory=cfg.STATIC_DIR), name="static")

# Админка (отдельная SPA)
if cfg.ADMIN_ENABLED and os.path.isdir(cfg.ADMIN_DIR):
    app.mount("/admin", StaticFiles(directory=cfg.ADMIN_DIR, html=True), name="admin")


# ====== HELPERS ======
def row_to_dict(row):
    if row is None:
        return None
    return dict(row)


def list_from_json(val, default=None):
    if not val:
        return default or []
    if isinstance(val, str):
        try:
            return json.loads(val)
        except (json.JSONDecodeError, TypeError):
            return default or []
    return val or default or []


def get_children_ids(page_id: str, conn) -> list:
    """Рекурсивно собирает ID всех дочерних страниц."""
    ids = []
    rows = conn.execute(
        "SELECT id FROM pages WHERE parent = ?", (page_id,)
    ).fetchall()
    for r in rows:
        ids.append(r["id"])
        ids.extend(get_children_ids(r["id"], conn))
    return ids


# ====== API: Pages ======
@app.get("/api/pages")
def api_get_pages():
    conn = get_db()
    rows = conn.execute("SELECT * FROM pages ORDER BY sort_order ASC, name ASC").fetchall()
    conn.close()
    return [row_to_dict(r) for r in rows]


@app.post("/api/pages")
def api_create_page(data: PageCreate):
    conn = get_db()
    data.id = data.id.strip().lower().replace(" ", "-").replace("--", "-")
    # Проверка уникальности
    existing = conn.execute("SELECT id FROM pages WHERE id = ?", (data.id,)).fetchone()
    if existing:
        conn.close()
        raise HTTPException(400, f"Страница с ID '{data.id}' уже существует")
    conn.execute(
        "INSERT INTO pages (id, name, icon, parent, sort_order, status) VALUES (?, ?, ?, ?, ?, 'draft')",
        (data.id, data.name, data.icon, data.parent, data.sort_order),
    )
    conn.commit()
    page = conn.execute("SELECT * FROM pages WHERE id = ?", (data.id,)).fetchone()
    conn.close()
    return row_to_dict(page)


@app.put("/api/pages/{page_id}")
def api_update_page(page_id: str, data: PageUpdate):
    conn = get_db()
    existing = conn.execute("SELECT * FROM pages WHERE id = ?", (page_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Страница не найдена")

    updates = {}
    if data.name is not None: updates["name"] = data.name
    if data.icon is not None: updates["icon"] = data.icon
    if data.parent is not None: updates["parent"] = data.parent or None
    if data.sort_order is not None: updates["sort_order"] = data.sort_order
    if data.status is not None: updates["status"] = data.status
    updates["updated_at"] = datetime.now().isoformat()

    for k, v in updates.items():
        conn.execute(f"UPDATE pages SET {k} = ? WHERE id = ?", (v, page_id))
    conn.commit()
    page = conn.execute("SELECT * FROM pages WHERE id = ?", (page_id,)).fetchone()
    conn.close()
    return row_to_dict(page)


@app.delete("/api/pages/{page_id}")
def api_delete_page(page_id: str):
    if page_id == "home":
        raise HTTPException(400, "Главную страницу нельзя удалить")
    conn = get_db()
    existing = conn.execute("SELECT * FROM pages WHERE id = ?", (page_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Страница не найдена")
    # Каскадное удаление детей
    child_ids = get_children_ids(page_id, conn)
    for cid in child_ids:
        conn.execute("DELETE FROM blocks WHERE page_id = ?", (cid,))
        conn.execute("DELETE FROM pages WHERE id = ?", (cid,))
    conn.execute("DELETE FROM blocks WHERE page_id = ?", (page_id,))
    conn.execute("DELETE FROM pages WHERE id = ?", (page_id,))
    conn.commit()
    conn.close()
    return {"success": True}


@app.put("/api/pages/reorder")
def api_reorder_pages(data: ReorderRequest):
    conn = get_db()
    for item in data.items:
        conn.execute("UPDATE pages SET sort_order = ? WHERE id = ?", (item.sort_order, item.id))
    conn.commit()
    conn.close()
    return {"success": True}


# ====== API: Blocks ======
@app.get("/api/pages/{page_id}/blocks")
def api_get_blocks(page_id: str):
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM blocks WHERE page_id = ? ORDER BY sort_order ASC", (page_id,)
    ).fetchall()
    conn.close()
    result = []
    for r in rows:
        d = row_to_dict(r)
        d["config"] = json.loads(d.get("config", "{}"))
        result.append(d)
    return result


@app.put("/api/pages/{page_id}/blocks")
def api_save_blocks(page_id: str, blocks: list = Body(...)):
    """Сохраняет все блоки страницы (заменяет существующие)."""
    conn = get_db()
    conn.execute("DELETE FROM blocks WHERE page_id = ?", (page_id,))
    for i, b in enumerate(blocks):
        bid = b.get("id")
        if not bid:
            bid = f"b{hashlib.md5(str(datetime.now()).encode()).hexdigest()[:8]}"
        btype = b.get("type", "text")
        bname = b.get("name", "Блок")
        bconfig = json.dumps(b.get("config", {}), ensure_ascii=False)

        # Если ID уже занят блоком другой страницы — генерируем уникальный
        existing = conn.execute(
            "SELECT id, page_id FROM blocks WHERE id = ?", (bid,)
        ).fetchone()
        if existing and existing["page_id"] != page_id:
            bid = f"b{hashlib.md5(f'{bid}_{datetime.now()}'.encode()).hexdigest()[:12]}"

        conn.execute(
            "INSERT INTO blocks (id, page_id, type, name, sort_order, config) VALUES (?, ?, ?, ?, ?, ?)",
            (bid, page_id, btype, bname, i, bconfig),
        )
    conn.commit()
    conn.close()
    return {"success": True}


@app.post("/api/blocks/{block_id}/move")
def api_move_block(block_id: str, direction: str = "down"):
    """Переместить блок вверх или вниз."""
    conn = get_db()
    block = conn.execute("SELECT * FROM blocks WHERE id = ?", (block_id,)).fetchone()
    if not block:
        conn.close()
        raise HTTPException(404, "Блок не найден")

    page_id = block["page_id"]
    current_order = block["sort_order"]

    if direction == "up":
        target = conn.execute(
            "SELECT * FROM blocks WHERE page_id = ? AND sort_order < ? ORDER BY sort_order DESC LIMIT 1",
            (page_id, current_order),
        ).fetchone()
    else:
        target = conn.execute(
            "SELECT * FROM blocks WHERE page_id = ? AND sort_order > ? ORDER BY sort_order ASC LIMIT 1",
            (page_id, current_order),
        ).fetchone()

    if target:
        conn.execute("UPDATE blocks SET sort_order = ? WHERE id = ?", (target["sort_order"], block_id))
        conn.execute("UPDATE blocks SET sort_order = ? WHERE id = ?", (current_order, target["id"]))
        conn.commit()

    conn.close()
    return {"success": True}


# ====== API: Roles ======
@app.get("/api/roles")
def api_get_roles():
    conn = get_db()
    rows = conn.execute("SELECT * FROM roles ORDER BY name ASC").fetchall()
    conn.close()
    result = []
    for r in rows:
        d = row_to_dict(r)
        d["sections"] = list_from_json(d["sections"], [])
        d["caps"] = list_from_json(d["caps"], {})
        # Имитация счётчика пользователей (на MVP всё в 0)
        d["users"] = 0
        result.append(d)
    return result


@app.post("/api/roles")
def api_create_role(data: RoleCreate):
    conn = get_db()
    rid = data.id or f"role_{data.name.lower().replace(' ', '_')}"
    conn.execute(
        "INSERT INTO roles (id, name, icon, sections, caps) VALUES (?, ?, ?, ?, ?)",
        (rid, data.name, data.icon, json.dumps(data.sections, ensure_ascii=False), json.dumps(data.caps, ensure_ascii=False)),
    )
    conn.commit()
    role = conn.execute("SELECT * FROM roles WHERE id = ?", (rid,)).fetchone()
    conn.close()
    return row_to_dict(role)


@app.put("/api/roles/{role_id}")
def api_update_role(role_id: str, data: RoleCreate):
    conn = get_db()
    existing = conn.execute("SELECT * FROM roles WHERE id = ?", (role_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(404, "Роль не найдена")
    conn.execute(
        "UPDATE roles SET name=?, icon=?, sections=?, caps=? WHERE id=?",
        (data.name, data.icon, json.dumps(data.sections, ensure_ascii=False), json.dumps(data.caps, ensure_ascii=False), role_id),
    )
    conn.commit()
    role = conn.execute("SELECT * FROM roles WHERE id = ?", (role_id,)).fetchone()
    conn.close()
    return row_to_dict(role)


@app.delete("/api/roles/{role_id}")
def api_delete_role(role_id: str):
    if role_id == "admin":
        raise HTTPException(400, "Роль администратора нельзя удалить")
    conn = get_db()
    conn.execute("DELETE FROM roles WHERE id = ?", (role_id,))
    conn.commit()
    conn.close()
    return {"success": True}


# ====== API: Settings ======
@app.get("/api/settings")
def api_get_settings():
    conn = get_db()
    rows = conn.execute("SELECT * FROM settings").fetchall()
    conn.close()
    result = {}
    for r in rows:
        result[r["key"]] = list_from_json(r["value"]) if r["key"] in ("menu_groups_config",) else r["value"]
    return result


@app.put("/api/settings")
def api_update_settings(settings: dict):
    conn = get_db()
    for k, v in settings.items():
        if isinstance(v, (dict, list)):
            v = json.dumps(v, ensure_ascii=False)
        elif v is None:
            v = ""
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (k, str(v)))
    conn.commit()
    conn.close()
    return {"success": True}


# ====== API: Media ======
@app.get("/api/media")
def api_get_media():
    conn = get_db()
    rows = conn.execute("SELECT * FROM media ORDER BY created_at DESC").fetchall()
    conn.close()
    result = []
    for r in rows:
        d = row_to_dict(r)
        d["url"] = f"/static/uploads/{d['filename']}"
        result.append(d)
    return result


@app.post("/api/media/upload")
async def api_upload_media(file: UploadFile = File(...), alt_text: str = ""):
    ext = Path(file.filename).suffix.lower()
    if ext not in cfg.ALLOWED_EXTENSIONS:
        raise HTTPException(400, f"Недопустимый тип файла: {ext}")
    # Читаем содержимое
    content = await file.read()
    if len(content) > cfg.MAX_UPLOAD_SIZE:
        raise HTTPException(400, "Файл слишком большой")
    # Уникальное имя
    file_hash = hashlib.md5(content).hexdigest()[:12]
    new_filename = f"{file_hash}{ext}"
    save_path = Path(cfg.UPLOAD_DIR) / new_filename
    # Сохраняем
    save_path.write_bytes(content)
    # В БД
    conn = get_db()
    conn.execute(
        "INSERT INTO media (filename, original_name, mime_type, size, alt_text) VALUES (?, ?, ?, ?, ?)",
        (new_filename, file.filename, file.content_type or "application/octet-stream", len(content), alt_text),
    )
    conn.commit()
    mid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.close()
    return {"id": mid, "filename": new_filename, "url": f"/static/uploads/{new_filename}"}


@app.delete("/api/media/{media_id}")
def api_delete_media(media_id: int):
    conn = get_db()
    item = conn.execute("SELECT * FROM media WHERE id = ?", (media_id,)).fetchone()
    if not item:
        conn.close()
        raise HTTPException(404, "Файл не найден")
    # Удаляем файл
    file_path = Path(cfg.UPLOAD_DIR) / item["filename"]
    if file_path.exists():
        file_path.unlink()
    conn.execute("DELETE FROM media WHERE id = ?", (media_id,))
    conn.commit()
    conn.close()
    return {"success": True}


# ====== API: Suggestions ======
@app.post("/api/suggest")
def api_suggest(data: SuggestionCreate):
    conn = get_db()
    conn.execute(
        "INSERT INTO suggestions (name, email, category, text) VALUES (?, ?, ?, ?)",
        (data.name, data.email, data.category, data.text),
    )
    conn.commit()
    conn.close()
    return {"success": True, "message": "Спасибо! Ваша новость отправлена на модерацию."}


@app.get("/api/suggestions")
def api_get_suggestions():
    conn = get_db()
    rows = conn.execute("SELECT * FROM suggestions ORDER BY created_at DESC LIMIT 50").fetchall()
    conn.close()
    return [row_to_dict(r) for r in rows]


# ====== API: Content (для публичного сайта) ======
@app.get("/api/content/pages")
def api_content_pages():
    """Публичные страницы с иерархией для навигации."""
    conn = get_db()
    rows = conn.execute(
        "SELECT id, name, icon, parent, sort_order FROM pages WHERE status='published' ORDER BY sort_order ASC"
    ).fetchall()
    conn.close()
    return [row_to_dict(r) for r in rows]


@app.get("/api/content/recent")
def api_content_recent(limit: int = 6):
    """Последние опубликованные страницы (имитация новостной ленты)."""
    conn = get_db()
    rows = conn.execute(
        "SELECT id, name, icon, updated_at FROM pages WHERE status='published' ORDER BY updated_at DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return [row_to_dict(r) for r in rows]


# ====== Публичный сайт (Jinja2) ======
def get_nav_tree(conn):
    """Строит дерево навигации для меню."""
    pages = conn.execute(
        "SELECT id, name, icon, parent FROM pages WHERE status='published' ORDER BY sort_order"
    ).fetchall()
    roots = [row_to_dict(p) for p in pages if not p["parent"]]
    children = {}
    for p in pages:
        pid = p["parent"]
        if pid:
            children.setdefault(pid, []).append(row_to_dict(p))
    for root in roots:
        root["children"] = children.get(root["id"], [])
        for child in root["children"]:
            child["children"] = children.get(child["id"], [])
    return roots


def get_page_with_blocks(slug: str, conn):
    """Возвращает страницу с блоками."""
    page = conn.execute(
        "SELECT * FROM pages WHERE id = ? AND status='published'", (slug,)
    ).fetchone()
    if not page:
        # Пробуем draft для предпросмотра
        page = conn.execute(
            "SELECT * FROM pages WHERE id = ?", (slug,)
        ).fetchone()
        if not page:
            return None, None
    blocks = conn.execute(
        "SELECT * FROM blocks WHERE page_id = ? ORDER BY sort_order ASC", (slug,)
    ).fetchall()
    blocks_data = []
    for b in blocks:
        bd = row_to_dict(b)
        bd["config"] = json.loads(bd.get("config", "{}"))
        blocks_data.append(bd)
    return row_to_dict(page), blocks_data


def get_breadcrumbs(page_id: str, conn) -> list:
    """Строит хлебные крошки."""
    crumbs = []
    current = conn.execute("SELECT id, name, parent FROM pages WHERE id = ?", (page_id,)).fetchone()
    while current:
        crumbs.insert(0, {"id": current["id"], "name": current["name"]})
        if current["parent"]:
            current = conn.execute(
                "SELECT id, name, parent FROM pages WHERE id = ?", (current["parent"],)
            ).fetchone()
        else:
            current = None
    return crumbs


@app.get("/", response_class=HTMLResponse)
def web_index(request: Request):
    conn = get_db()
    pages = get_nav_tree(conn)
    _page, blocks = get_page_with_blocks("home", conn)
    settings = {r["key"]: r["value"] for r in conn.execute("SELECT * FROM settings").fetchall()}
    # Публичные разделы (без подразделов, для бенто-сетки)
    sections = [
        row_to_dict(r) for r in conn.execute(
            "SELECT id, name, icon FROM pages WHERE parent IS NULL AND status='published' ORDER BY sort_order"
        ).fetchall()
    ]
    conn.close()
    return HTMLResponse(render(
        "index.html",
        pages=pages,
        blocks=blocks,
        settings=settings,
        sections=sections,
        recent_news=sections[:3],
        page_title="Главная",
    ))


@app.get("/{slug:path}", response_class=HTMLResponse)
def web_page(slug: str, request: Request):
    # Игнорируем api/admins пути
    if slug.startswith("api/") or slug.startswith("admin"):
        raise HTTPException(404)

    slug = slug.rstrip("/").split("/")[-1]  # last segment
    conn = get_db()
    page, blocks = get_page_with_blocks(slug, conn)
    if not page:
        # 404
        pages = get_nav_tree(conn)
        settings = {r["key"]: r["value"] for r in conn.execute("SELECT * FROM settings").fetchall()}
        conn.close()
        return HTMLResponse(render("errors/404.html", pages=pages, settings=settings, slug=slug))

    pages = get_nav_tree(conn)
    settings = {r["key"]: r["value"] for r in conn.execute("SELECT * FROM settings").fetchall()}
    breadcrumbs = get_breadcrumbs(slug, conn)
    conn.close()

    return HTMLResponse(render(
        "page.html",
        page=page,
        blocks=blocks,
        pages=pages,
        settings=settings,
        breadcrumbs=breadcrumbs,
        page_title=page["name"],
    ))


# ====== Запуск ======
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
