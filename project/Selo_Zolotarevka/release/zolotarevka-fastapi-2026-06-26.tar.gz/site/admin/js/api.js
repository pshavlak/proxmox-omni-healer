/**
 * API client for Золотаревка admin panel.
 * All functions return Promises with parsed JSON.
 */

const api = {
  // ====== Pages ======
  getPages: () =>
    fetch('/api/pages').then(r => {
      if (!r.ok) throw new Error('Ошибка загрузки страниц');
      return r.json();
    }),

  createPage: (data) =>
    fetch('/api/pages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    }).then(r => {
      if (!r.ok) return r.json().then(e => { throw new Error(e.detail || 'Ошибка создания'); });
      return r.json();
    }),

  updatePage: (id, data) =>
    fetch(`/api/pages/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    }).then(r => {
      if (!r.ok) return r.json().then(e => { throw new Error(e.detail || 'Ошибка обновления'); });
      return r.json();
    }),

  deletePage: (id) =>
    fetch(`/api/pages/${id}`, {
      method: 'DELETE',
    }).then(r => {
      if (!r.ok) return r.json().then(e => { throw new Error(e.detail || 'Ошибка удаления'); });
      return r.json();
    }),

  reorderPages: (items) =>
    fetch('/api/pages/reorder', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items }),
    }).then(r => {
      if (!r.ok) throw new Error('Ошибка сортировки');
      return r.json();
    }),

  // ====== Blocks ======
  getBlocks: (pageId) =>
    fetch(`/api/pages/${pageId}/blocks`).then(r => {
      if (!r.ok) throw new Error('Ошибка загрузки блоков');
      return r.json();
    }),

  saveBlocks: (pageId, blocks) =>
    fetch(`/api/pages/${pageId}/blocks`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(blocks),
    }).then(r => {
      if (!r.ok) throw new Error('Ошибка сохранения блоков');
      return r.json();
    }),

  moveBlock: (id, direction) =>
    fetch(`/api/blocks/${id}/move?direction=${direction}`, {
      method: 'POST',
    }).then(r => {
      if (!r.ok) throw new Error('Ошибка перемещения блока');
      return r.json();
    }),

  // ====== Roles ======
  getRoles: () =>
    fetch('/api/roles').then(r => {
      if (!r.ok) throw new Error('Ошибка загрузки ролей');
      return r.json();
    }),

  createRole: (data) =>
    fetch('/api/roles', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    }).then(r => {
      if (!r.ok) return r.json().then(e => { throw new Error(e.detail || 'Ошибка создания'); });
      return r.json();
    }),

  updateRole: (id, data) =>
    fetch(`/api/roles/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    }).then(r => {
      if (!r.ok) return r.json().then(e => { throw new Error(e.detail || 'Ошибка обновления'); });
      return r.json();
    }),

  deleteRole: (id) =>
    fetch(`/api/roles/${id}`, {
      method: 'DELETE',
    }).then(r => {
      if (!r.ok) return r.json().then(e => { throw new Error(e.detail || 'Ошибка удаления'); });
      return r.json();
    }),

  // ====== Settings ======
  getSettings: () =>
    fetch('/api/settings').then(r => {
      if (!r.ok) throw new Error('Ошибка загрузки настроек');
      return r.json();
    }),

  saveSettings: (settings) =>
    fetch('/api/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    }).then(r => {
      if (!r.ok) throw new Error('Ошибка сохранения настроек');
      return r.json();
    }),

  // ====== Media ======
  getMedia: () =>
    fetch('/api/media').then(r => {
      if (!r.ok) throw new Error('Ошибка загрузки медиа');
      return r.json();
    }),

  uploadFile: (file) => {
    const fd = new FormData();
    fd.append('file', file);
    return fetch('/api/media/upload', {
      method: 'POST',
      body: fd,
    }).then(r => {
      if (!r.ok) throw new Error('Ошибка загрузки файла');
      return r.json();
    });
  },

  deleteMedia: (id) =>
    fetch(`/api/media/${id}`, {
      method: 'DELETE',
    }).then(r => {
      if (!r.ok) throw new Error('Ошибка удаления файла');
      return r.json();
    }),
};
